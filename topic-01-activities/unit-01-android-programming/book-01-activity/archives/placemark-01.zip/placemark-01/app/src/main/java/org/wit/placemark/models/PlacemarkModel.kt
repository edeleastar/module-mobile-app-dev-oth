package org.wit.placemark.models

data class PlacemarkModel(var title: String = "")


